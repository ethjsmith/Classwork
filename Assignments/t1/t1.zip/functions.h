/*
* Modified by Ethan Smith
* 10/5/20
*/

/*You'll have to add things in here to make everything connect appropriatly*/
#include "planets.h"
# ifndef FUNCTIONS_H
#define FUNCTIONS_H

extern double currentCal;

double getGravity(int);

void setCalories(double, grav::Planet, double);
#endif