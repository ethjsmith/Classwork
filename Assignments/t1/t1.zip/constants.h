/*
* Modified by Ethan Smith
* 10/5/20
*/
/*Place constants in here and then include this wherever you want to access those constants*/
# ifndef CONSTANTS_H
#define CONSTANTS_H


//Move to constants.h
const double CALCONST = 0.2390057361; 
#endif